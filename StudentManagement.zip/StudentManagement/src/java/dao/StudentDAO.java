/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Student;

public class StudentDAO {

    private String jdbcURL = "jdbc:mysql://localhost:3306/studentdb";
    private String jdbcUsername = "root";
    private String jdbcPassword = ""; // đổi nếu MySQL bạn có mật khẩu

    private static final String INSERT_STUDENTS_SQL = "INSERT INTO students (name, email, country) VALUES (?, ?, ?);";
    private static final String SELECT_STUDENT_BY_ID = "SELECT id, name, email, country FROM students WHERE id = ?";
    private static final String SELECT_ALL_STUDENTS = "SELECT * FROM students";
    private static final String DELETE_STUDENTS_SQL = "DELETE FROM students WHERE id = ?;";
    private static final String UPDATE_STUDENTS_SQL = "UPDATE students SET name = ?, email = ?, country = ? WHERE id = ?;";

    protected Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            System.out.println("=== KẾT NỐI MySQL THÀNH CÔNG ===");
        } catch (Exception e) {
            System.out.println("=== KẾT NỐI MySQL THẤT BẠI ===");
            e.printStackTrace();
        }
        return connection;
    }

    // Thêm sinh viên
    public void insertStudent(Student student) {
        try (Connection connection = getConnection();
             PreparedStatement ps = connection.prepareStatement(INSERT_STUDENTS_SQL)) {
            ps.setString(1, student.getName());
            ps.setString(2, student.getEmail());
            ps.setString(3, student.getCountry());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Lấy 1 sinh viên theo ID
    public Student selectStudent(int id) {
        Student student = null;
        try (Connection connection = getConnection();
             PreparedStatement ps = connection.prepareStatement(SELECT_STUDENT_BY_ID)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String name = rs.getString("name");
                String email = rs.getString("email");
                String country = rs.getString("country");
                student = new Student(id, name, email, country);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return student;
    }

    // Lấy tất cả sinh viên
    public List<Student> selectAllStudents() {
        List<Student> students = new ArrayList<>();
        try (Connection connection = getConnection();
             PreparedStatement ps = connection.prepareStatement(SELECT_ALL_STUDENTS)) {
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String email = rs.getString("email");
                String country = rs.getString("country");
                students.add(new Student(id, name, email, country));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return students;
    }

    // Xóa sinh viên
    public boolean deleteStudent(int id) {
        boolean rowDeleted = false;
        try (Connection connection = getConnection();
             PreparedStatement ps = connection.prepareStatement(DELETE_STUDENTS_SQL)) {
            ps.setInt(1, id);
            rowDeleted = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rowDeleted;
    }

    // Cập nhật sinh viên
    public boolean updateStudent(Student student) {
        boolean rowUpdated = false;
        try (Connection connection = getConnection();
             PreparedStatement ps = connection.prepareStatement(UPDATE_STUDENTS_SQL)) {
            ps.setString(1, student.getName());
            ps.setString(2, student.getEmail());
            ps.setString(3, student.getCountry());
            ps.setInt(4, student.getId());
            rowUpdated = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rowUpdated;
    }
    
}
